import { useState, useEffect } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

// ── Live Price Ticker ──────────────────────────────────────────────────────
function useLivePrice() {
  const [price, setPrice] = useState(0.0444);
  const [change, setChange] = useState(4.44);
  useEffect(() => {
    const interval = setInterval(() => {
      setPrice(p => Math.max(0.001, p * (1 + (Math.random() - 0.48) * 0.02)));
      setChange(c => c + (Math.random() - 0.5) * 0.3);
    }, 3000);
    return () => clearInterval(interval);
  }, []);
  return { price, change };
}

// ── Animated Counter ──────────────────────────────────────────────────────
function Counter({ end, suffix = "", prefix = "" }: { end: number; suffix?: string; prefix?: string }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    const step = end / 60;
    let current = 0;
    const timer = setInterval(() => {
      current = Math.min(current + step, end);
      setCount(Math.floor(current));
      if (current >= end) clearInterval(timer);
    }, 25);
    return () => clearInterval(timer);
  }, [end]);
  return <span>{prefix}{count.toLocaleString()}{suffix}</span>;
}

const FEATURES = [
  { icon: "🤖", title: "HOPE AI", desc: "44 specialized AI agents — trade, create, coach, analyze. Earn SKY444 with every interaction.", color: "from-purple-600 to-blue-600", link: "/hope-ai" },
  { icon: "💬", title: "ShadowChat", desc: "Anonymous or public — real-time encrypted messaging with identity modes and AI moderation.", color: "from-blue-600 to-cyan-600", link: "/messages" },
  { icon: "💰", title: "SKY444 Token", desc: "Native crypto — earn, spend, stake, tip. No Coinbase needed. 15–60% APY staking.", color: "from-yellow-500 to-orange-500", link: "/token-dashboard" },
  { icon: "🎮", title: "GameFi + Charity", desc: "Bingo, Slots, Crash, Roulette — 10% of every bet funds real-world charity campaigns.", color: "from-green-600 to-emerald-600", link: "/charity-games" },
  { icon: "🛒", title: "Marketplace", desc: "NFT trading, digital goods, escrow protection. Creator economy with 70% revenue share.", color: "from-pink-600 to-rose-600", link: "/marketplace" },
  { icon: "📺", title: "Live Streaming", desc: "Stream to thousands, earn SKY444 donations, run tournaments and live events.", color: "from-red-600 to-pink-600", link: "/streaming" },
  { icon: "🏛️", title: "DAO Governance", desc: "Vote on platform decisions with SKY444. Shape the future of the ecosystem.", color: "from-indigo-600 to-purple-600", link: "/governance" },
  { icon: "🌍", title: "Charity Network", desc: "6 active campaigns. Every platform action contributes to real-world impact.", color: "from-emerald-600 to-teal-600", link: "/charity-games" },
];

const CRYPTO_BRIDGES = [
  { name: "Ethereum", icon: "⟠", status: "Coming Q3 2026", color: "text-blue-400" },
  { name: "Solana", icon: "◎", status: "Coming Q3 2026", color: "text-purple-400" },
  { name: "BNB Chain", icon: "⬡", status: "Coming Q4 2026", color: "text-yellow-400" },
  { name: "Polygon", icon: "⬟", status: "Coming Q4 2026", color: "text-violet-400" },
  { name: "Base", icon: "🔵", status: "Coming Q1 2027", color: "text-blue-300" },
];

const AI_ECONOMY = [
  { action: "Chat with HOPE AI", earn: "+0.5 SKY444", icon: "💬" },
  { action: "Generate AI Image", earn: "+5 SKY444", icon: "🎨" },
  { action: "AI Code Generation", earn: "+3 SKY444", icon: "💻" },
  { action: "Share AI Output", earn: "+5 SKY444", icon: "📤" },
  { action: "Tip a Creator", earn: "70% to creator", icon: "💝" },
  { action: "Daily Login Streak", earn: "+10–444 SKY444", icon: "🔥" },
  { action: "Win at Bingo", earn: "5x your bet", icon: "🎱" },
  { action: "Refer a Friend", earn: "+100 SKY444", icon: "👥" },
];

export default function LandingPage() {
  const { price, change } = useLivePrice();
  const [email, setEmail] = useState("");
  const [joined, setJoined] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-white overflow-x-hidden">

      {/* ── Top Ticker Bar ──────────────────────────────────────────────── */}
      <div className="bg-slate-900 border-b border-slate-800 py-2 px-4 overflow-hidden">
        <div className="flex items-center gap-6 text-sm animate-marquee whitespace-nowrap">
          <span className="text-yellow-400 font-bold">SKY444: ${price.toFixed(4)}</span>
          <span className={change >= 0 ? "text-green-400" : "text-red-400"}>
            {change >= 0 ? "▲" : "▼"} {Math.abs(change).toFixed(2)}%
          </span>
          <span className="text-slate-400">Vol: $4.4M</span>
          <span className="text-slate-400">|</span>
          <span className="text-purple-400">🎱 Bingo Jackpot: 44,444 SKY444</span>
          <span className="text-slate-400">|</span>
          <span className="text-emerald-400">🌍 Charity Raised: $231,540</span>
          <span className="text-slate-400">|</span>
          <span className="text-blue-400">⟠ ETH Bridge: Coming Q3 2026</span>
          <span className="text-slate-400">|</span>
          <span className="text-yellow-400">🔥 Staking APY: up to 60%</span>
        </div>
      </div>

      {/* ── Nav ─────────────────────────────────────────────────────────── */}
      <nav className="sticky top-0 z-50 bg-slate-950/90 backdrop-blur-xl border-b border-slate-800/50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-400 to-purple-600 flex items-center justify-center font-black text-lg">S</div>
            <span className="font-black text-xl text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-purple-400">SKYCOIN4444</span>
          </div>
          <div className="hidden md:flex items-center gap-6 text-sm text-slate-400">
            <Link href="/token-dashboard" className="hover:text-white transition-colors">Token</Link>
            <Link href="/charity-games" className="hover:text-white transition-colors">Games</Link>
            <Link href="/hope-ai" className="hover:text-white transition-colors">HOPE AI</Link>
            <Link href="/marketplace" className="hover:text-white transition-colors">Market</Link>
            <Link href="/staking-portal" className="hover:text-white transition-colors">Stake</Link>
          </div>
          <div className="flex items-center gap-3">
            <Badge className="bg-green-600/20 text-green-400 border border-green-600/30 text-xs">● LIVE</Badge>
            <Link href="/dashboard">
              <Button className="bg-gradient-to-r from-yellow-500 to-purple-600 hover:from-yellow-600 hover:to-purple-700 text-white font-bold text-sm px-5">
                Launch App
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* ── Hero ─────────────────────────────────────────────────────────── */}
      <section className="relative min-h-screen flex items-center justify-center px-6 py-20 overflow-hidden">
        {/* Background glow */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-yellow-500/10 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/5 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-5xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <Badge className="bg-purple-600/20 text-purple-300 border border-purple-600/30 mb-6 text-sm px-4 py-1">
              🚀 The Future of Social Finance is Here
            </Badge>
            <h1 className="text-6xl md:text-8xl font-black leading-none mb-6">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-purple-400 to-cyan-400">
                Chat. Earn.
              </span>
              <br />
              <span className="text-white">Create. Win.</span>
            </h1>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto mb-10 leading-relaxed">
              SKYCOIN4444 is the AI-powered Web3 social ecosystem where every action earns you <strong className="text-yellow-400">SKY444 tokens</strong>.
              Chat with AI, play charity games, stake for 60% APY, and govern the platform — all in one place.
            </p>

            {/* Live Price Card */}
            <div className="inline-flex items-center gap-4 bg-slate-900/80 border border-slate-700 rounded-2xl px-6 py-4 mb-10">
              <div className="text-left">
                <div className="text-xs text-slate-400">SKY444 Price</div>
                <div className="text-2xl font-black text-yellow-400">${price.toFixed(4)}</div>
              </div>
              <div className="w-px h-10 bg-slate-700" />
              <div className="text-left">
                <div className="text-xs text-slate-400">24h Change</div>
                <div className={`text-xl font-bold ${change >= 0 ? "text-green-400" : "text-red-400"}`}>
                  {change >= 0 ? "+" : ""}{change.toFixed(2)}%
                </div>
              </div>
              <div className="w-px h-10 bg-slate-700" />
              <div className="text-left">
                <div className="text-xs text-slate-400">Staking APY</div>
                <div className="text-xl font-bold text-purple-400">Up to 60%</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/dashboard">
                <Button size="lg" className="bg-gradient-to-r from-yellow-500 to-purple-600 hover:from-yellow-600 hover:to-purple-700 text-white font-black text-lg px-10 h-14 shadow-lg shadow-purple-500/30">
                  🚀 Start Earning SKY444
                </Button>
              </Link>
              <Link href="/token-dashboard">
                <Button size="lg" variant="outline" className="border-slate-600 text-white hover:bg-slate-800 font-bold text-lg px-10 h-14">
                  📊 View Token
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── Stats Bar ────────────────────────────────────────────────────── */}
      <section className="bg-slate-900/50 border-y border-slate-800 py-12 px-6">
        <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[
            { label: "Active Users", value: 44444, suffix: "+", color: "text-yellow-400" },
            { label: "SKY444 Earned", value: 8888888, suffix: "+", color: "text-purple-400" },
            { label: "Charity Raised", prefix: "$", value: 231540, color: "text-emerald-400" },
            { label: "Games Played", value: 941000, suffix: "+", color: "text-blue-400" },
          ].map((stat, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
              <div className={`text-4xl font-black ${stat.color}`}>
                <Counter end={stat.value} suffix={stat.suffix} prefix={stat.prefix} />
              </div>
              <div className="text-slate-400 text-sm mt-1">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ── AI Economy ───────────────────────────────────────────────────── */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <Badge className="bg-yellow-600/20 text-yellow-400 border border-yellow-600/30 mb-4">AI Economics</Badge>
            <h2 className="text-4xl font-black text-white">Every Action Earns SKY444</h2>
            <p className="text-slate-400 mt-3 max-w-2xl mx-auto">Our AI economics engine rewards you for every interaction. Earn, spend, share, and tip — the token flows everywhere.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {AI_ECONOMY.map((item, i) => (
              <motion.div key={i} initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                className="bg-slate-900 border border-slate-700 rounded-2xl p-4 hover:border-yellow-600/50 transition-all group">
                <div className="text-3xl mb-3">{item.icon}</div>
                <div className="text-white font-semibold text-sm mb-1">{item.action}</div>
                <div className="text-yellow-400 font-black text-sm">{item.earn}</div>
              </motion.div>
            ))}
          </div>
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            {[
              { icon: "💰", title: "EARN", desc: "Use AI, play games, create content, refer friends — every action pays" },
              { icon: "🛍️", title: "SPEND", desc: "Unlock premium AI models, boost posts, mint NFTs, enter tournaments" },
              { icon: "💝", title: "TIP & SHARE", desc: "Tip creators directly — 70% goes to them instantly. Share AI outputs for bonus SKY444" },
            ].map((item, i) => (
              <div key={i} className="bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700 rounded-2xl p-6">
                <div className="text-4xl mb-3">{item.icon}</div>
                <div className="text-xl font-black text-white mb-2">{item.title}</div>
                <div className="text-slate-400 text-sm">{item.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Features Grid ────────────────────────────────────────────────── */}
      <section className="py-20 px-6 bg-slate-900/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <Badge className="bg-purple-600/20 text-purple-400 border border-purple-600/30 mb-4">941+ Features</Badge>
            <h2 className="text-4xl font-black text-white">Everything in One Ecosystem</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {FEATURES.map((feature, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}>
                <Link href={feature.link}>
                  <Card className="bg-slate-900 border-slate-700 hover:border-slate-500 transition-all cursor-pointer group h-full">
                    <CardContent className="p-5">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center text-2xl mb-4 group-hover:scale-110 transition-transform`}>
                        {feature.icon}
                      </div>
                      <h3 className="text-white font-black text-lg mb-2">{feature.title}</h3>
                      <p className="text-slate-400 text-sm leading-relaxed">{feature.desc}</p>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Native Crypto + Coming Soon ──────────────────────────────────── */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <Badge className="bg-blue-600/20 text-blue-400 border border-blue-600/30 mb-4">Native Crypto</Badge>
            <h2 className="text-4xl font-black text-white">SKY444 — Our Own Blockchain</h2>
            <p className="text-slate-400 mt-3 max-w-2xl mx-auto">
              No Coinbase. No third-party dependency. SKY444 runs on its own native chain with a built-in DEX, staking, and mining.
              Multi-chain bridges launching soon.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-10">
            {/* Token Stats */}
            <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6">
              <h3 className="text-white font-black text-xl mb-5">📊 Token Economics</h3>
              <div className="space-y-3">
                {[
                  { label: "Total Supply", value: "444,444,444 SKY444", color: "text-yellow-400" },
                  { label: "Circulating", value: "88,888,888 SKY444", color: "text-green-400" },
                  { label: "Staking APY", value: "15% – 60%", color: "text-purple-400" },
                  { label: "Charity Reserve", value: "5% of supply", color: "text-emerald-400" },
                  { label: "Community Rewards", value: "40% of supply", color: "text-blue-400" },
                  { label: "Block Time", value: "~3 seconds", color: "text-cyan-400" },
                ].map(item => (
                  <div key={item.label} className="flex justify-between items-center py-2 border-b border-slate-800">
                    <span className="text-slate-400 text-sm">{item.label}</span>
                    <span className={`font-bold text-sm ${item.color}`}>{item.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Staking Tiers */}
            <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6">
              <h3 className="text-white font-black text-xl mb-5">🏦 Staking Tiers</h3>
              <div className="space-y-2">
                {[
                  { tier: "🥉 Bronze", min: "100 SKY444", lock: "7 days", apy: "15% APY" },
                  { tier: "🥈 Silver", min: "1,000 SKY444", lock: "30 days", apy: "25% APY" },
                  { tier: "🥇 Gold", min: "5,000 SKY444", lock: "90 days", apy: "35% APY" },
                  { tier: "💎 Diamond", min: "25,000 SKY444", lock: "180 days", apy: "45% APY" },
                  { tier: "🌟 SKY Elite", min: "100,000 SKY444", lock: "365 days", apy: "60% APY" },
                ].map(row => (
                  <div key={row.tier} className="flex items-center justify-between p-3 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors">
                    <span className="text-white text-sm font-semibold">{row.tier}</span>
                    <span className="text-slate-400 text-xs">{row.min}</span>
                    <span className="text-slate-500 text-xs">{row.lock}</span>
                    <span className="text-green-400 font-black text-sm">{row.apy}</span>
                  </div>
                ))}
              </div>
              <Link href="/staking-portal">
                <Button className="w-full mt-4 bg-purple-600 hover:bg-purple-700">Start Staking</Button>
              </Link>
            </div>
          </div>

          {/* Bridge Coming Soon */}
          <div className="bg-gradient-to-r from-slate-900 to-slate-800 border border-slate-700 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-5">
              <span className="text-2xl">🌉</span>
              <h3 className="text-white font-black text-xl">Multi-Chain Bridge — Coming Soon</h3>
              <Badge className="bg-orange-600/20 text-orange-400 border border-orange-600/30">In Development</Badge>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {CRYPTO_BRIDGES.map(bridge => (
                <div key={bridge.name} className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                  <div className={`text-3xl mb-2 ${bridge.color}`}>{bridge.icon}</div>
                  <div className="text-white font-bold text-sm">{bridge.name}</div>
                  <div className="text-slate-500 text-xs mt-1">{bridge.status}</div>
                </div>
              ))}
            </div>
            <p className="text-slate-400 text-sm mt-4 text-center">
              SKY444 will be bridgeable to all major chains. No Coinbase required — our native DEX handles all swaps.
            </p>
          </div>
        </div>
      </section>

      {/* ── Charity Section ───────────────────────────────────────────────── */}
      <section className="py-20 px-6 bg-gradient-to-r from-emerald-950/50 to-slate-950">
        <div className="max-w-5xl mx-auto text-center">
          <Badge className="bg-emerald-600/20 text-emerald-400 border border-emerald-600/30 mb-4">Play for Good</Badge>
          <h2 className="text-4xl font-black text-white mb-4">Games That Change the World</h2>
          <p className="text-slate-300 text-lg max-w-2xl mx-auto mb-10">
            Every game on SKYCOIN4444 contributes to real charity campaigns. Bingo, Slots, Scratch Cards — play and give at the same time.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
            {["🌾 End World Hunger", "📚 Education for All", "🌍 Climate Action", "🏠 Homes for All", "💧 Clean Water", "🐾 Animal Rescue"].map(cause => (
              <div key={cause} className="bg-slate-900/80 border border-emerald-800/30 rounded-xl p-4 text-white font-semibold text-sm">
                {cause}
              </div>
            ))}
          </div>
          <Link href="/charity-games">
            <Button size="lg" className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-lg px-10 h-14">
              🎱 Play Charity Games
            </Button>
          </Link>
        </div>
      </section>

      {/* ── CTA / Email Signup ────────────────────────────────────────────── */}
      <section className="py-20 px-6">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-4xl font-black text-white mb-4">Ready to Join the Ecosystem?</h2>
          <p className="text-slate-400 mb-8">Start with 100 free SKY444 tokens. No credit card required.</p>
          {!joined ? (
            <div className="flex gap-3 max-w-md mx-auto">
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="flex-1 bg-slate-800 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
              />
              <Button
                onClick={() => email && setJoined(true)}
                className="bg-gradient-to-r from-yellow-500 to-purple-600 hover:from-yellow-600 hover:to-purple-700 text-white font-bold px-6"
              >
                Join
              </Button>
            </div>
          ) : (
            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-center">
              <div className="text-5xl mb-3">🎉</div>
              <div className="text-2xl font-black text-yellow-400">Welcome! +100 SKY444 credited</div>
              <Link href="/dashboard">
                <Button className="mt-4 bg-purple-600 hover:bg-purple-700">Go to Dashboard</Button>
              </Link>
            </motion.div>
          )}
          <div className="mt-6 flex justify-center gap-6 text-sm text-slate-500">
            <span>✓ Free to join</span>
            <span>✓ 100 SKY444 welcome bonus</span>
            <span>✓ No KYC required</span>
          </div>
        </div>
      </section>

      {/* ── Footer ───────────────────────────────────────────────────────── */}
      <footer className="bg-slate-900 border-t border-slate-800 py-12 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="font-black text-white mb-3">SKYCOIN4444</div>
              <p className="text-slate-400 text-sm">The AI-powered Web3 social ecosystem. Chat, earn, create, govern.</p>
            </div>
            {[
              { title: "Platform", links: ["Dashboard", "HOPE AI", "ShadowChat", "Marketplace", "Streaming"] },
              { title: "Crypto", links: ["SKY444 Token", "Staking", "Trading", "Wallet", "Bridge (Soon)"] },
              { title: "Community", links: ["Charity Games", "Governance", "Leaderboard", "Referrals", "Discord"] },
            ].map(col => (
              <div key={col.title}>
                <div className="font-bold text-white mb-3 text-sm">{col.title}</div>
                <ul className="space-y-2">
                  {col.links.map(link => (
                    <li key={link}><span className="text-slate-400 text-sm hover:text-white cursor-pointer transition-colors">{link}</span></li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="border-t border-slate-800 pt-6 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-slate-500 text-sm">© 2026 SKYCOIN4444 Ecosystem. Built by Skyler Spillers.</div>
            <div className="flex items-center gap-4 text-sm text-slate-500">
              <span>GitHub: skylerblue333</span>
              <span>•</span>
              <span>SKY444: ${price.toFixed(4)}</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

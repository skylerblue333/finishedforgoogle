import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const EARN_ACTIONS = [
  { category: "AI", icon: "🤖", actions: [
    { name: "Chat with HOPE AI", reward: "+0.5 SKY444", per: "per message", color: "text-purple-400" },
    { name: "Generate AI Image", reward: "+5 SKY444", per: "per image", color: "text-purple-400" },
    { name: "AI Code Generation", reward: "+3 SKY444", per: "per session", color: "text-purple-400" },
    { name: "AI Trade Signal", reward: "+10 SKY444", per: "per signal", color: "text-purple-400" },
    { name: "Complete AI Task", reward: "+8 SKY444", per: "per task", color: "text-purple-400" },
  ]},
  { category: "Social", icon: "👥", actions: [
    { name: "Create Post", reward: "+1 SKY444", per: "per post", color: "text-blue-400" },
    { name: "Post Goes Viral", reward: "+50 SKY444", per: "1000+ likes", color: "text-blue-400" },
    { name: "Daily Login", reward: "+10 SKY444", per: "per day", color: "text-blue-400" },
    { name: "7-Day Streak", reward: "+70 SKY444", per: "bonus", color: "text-blue-400" },
    { name: "30-Day Streak", reward: "+444 SKY444", per: "bonus", color: "text-blue-400" },
  ]},
  { category: "Referrals", icon: "🤝", actions: [
    { name: "Friend Signs Up", reward: "+100 SKY444", per: "per referral", color: "text-green-400" },
    { name: "Friend Purchases", reward: "+25 SKY444", per: "per purchase", color: "text-green-400" },
    { name: "Link Clicks", reward: "+0.1 SKY444", per: "per click", color: "text-green-400" },
    { name: "Share AI Output", reward: "+5 SKY444", per: "per share", color: "text-green-400" },
  ]},
  { category: "Games", icon: "🎮", actions: [
    { name: "Bingo Win", reward: "+5x bet", per: "per win", color: "text-yellow-400" },
    { name: "Slots Jackpot", reward: "+100x bet", per: "jackpot", color: "text-yellow-400" },
    { name: "Charity Donation", reward: "+20 SKY444", per: "bonus", color: "text-yellow-400" },
  ]},
];

const SPEND_ACTIONS = [
  { name: "Premium AI Model (GPT-4)", cost: "10 SKY444", icon: "🧠" },
  { name: "HD Image Generation", cost: "15 SKY444", icon: "🎨" },
  { name: "AI Video Generation", cost: "50 SKY444", icon: "🎬" },
  { name: "Hire AI Agent (24h)", cost: "100 SKY444", icon: "🤖" },
  { name: "Boost Post", cost: "20 SKY444", icon: "📈" },
  { name: "Mint NFT", cost: "30 SKY444", icon: "🖼️" },
  { name: "Premium Subscription", cost: "999 SKY444/mo", icon: "⭐" },
  { name: "Marketplace Listing", cost: "5 SKY444", icon: "🛒" },
];

const MOCK_TRANSACTIONS = [
  { type: "earn", icon: "🤖", desc: "AI Chat with HOPE", amount: "+0.5", time: "2m ago" },
  { type: "earn", icon: "🎱", desc: "Bingo Win", amount: "+50", time: "15m ago" },
  { type: "spend", icon: "🧠", desc: "Premium AI Model", amount: "-10", time: "1h ago" },
  { type: "tip", icon: "💝", desc: "Tipped @creator_sky", amount: "-25", time: "2h ago" },
  { type: "earn", icon: "🔥", desc: "7-Day Streak Bonus", amount: "+70", time: "5h ago" },
  { type: "earn", icon: "👥", desc: "Referral Signup", amount: "+100", time: "1d ago" },
  { type: "charity", icon: "🌍", desc: "Donated to Climate Fund", amount: "-50", time: "1d ago" },
  { type: "earn", icon: "🌍", desc: "Charity Donation Bonus", amount: "+20", time: "1d ago" },
];

export default function AIEconomics() {
  const [balance] = useState(1247);
  const [staked] = useState(500);
  const [earned] = useState(3840);
  const [spent] = useState(285);
  const [tipped] = useState(125);
  const [tipAmount, setTipAmount] = useState(10);
  const [tipTarget, setTipTarget] = useState("");
  const [tipSent, setTipSent] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950/20 to-slate-950 p-4">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* Header */}
        <div className="text-center py-6">
          <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-purple-400">
            💰 AI Economics Dashboard
          </h1>
          <p className="text-slate-400 mt-2">Your SKY444 earn, spend, share & tip activity</p>
        </div>

        {/* Balance Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Balance", value: balance, icon: "💎", color: "from-yellow-500 to-orange-500", suffix: " SKY444" },
            { label: "Total Earned", value: earned, icon: "📈", color: "from-green-500 to-emerald-500", suffix: " SKY444" },
            { label: "Staked", value: staked, icon: "🏦", color: "from-purple-500 to-blue-500", suffix: " SKY444" },
            { label: "Tips Sent", value: tipped, icon: "💝", color: "from-pink-500 to-rose-500", suffix: " SKY444" },
          ].map((card, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
              <Card className="bg-slate-900 border-slate-700">
                <CardContent className="p-4">
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${card.color} flex items-center justify-center text-xl mb-3`}>
                    {card.icon}
                  </div>
                  <div className="text-2xl font-black text-white">{card.value.toLocaleString()}</div>
                  <div className="text-slate-400 text-xs mt-1">{card.label}</div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <Tabs defaultValue="earn" className="w-full">
          <TabsList className="bg-slate-900 border border-slate-700 w-full grid grid-cols-4">
            <TabsTrigger value="earn">💰 Earn</TabsTrigger>
            <TabsTrigger value="spend">🛍️ Spend</TabsTrigger>
            <TabsTrigger value="tip">💝 Tip</TabsTrigger>
            <TabsTrigger value="history">📋 History</TabsTrigger>
          </TabsList>

          {/* EARN Tab */}
          <TabsContent value="earn" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {EARN_ACTIONS.map(category => (
                <Card key={category.category} className="bg-slate-900 border-slate-700">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-white text-base flex items-center gap-2">
                      {category.icon} {category.category}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {category.actions.map(action => (
                      <div key={action.name} className="flex items-center justify-between p-2 rounded-lg bg-slate-800/50 hover:bg-slate-800 transition-colors">
                        <span className="text-slate-300 text-sm">{action.name}</span>
                        <div className="text-right">
                          <div className={`font-bold text-sm ${action.color}`}>{action.reward}</div>
                          <div className="text-slate-500 text-xs">{action.per}</div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* SPEND Tab */}
          <TabsContent value="spend" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {SPEND_ACTIONS.map(action => (
                <div key={action.name} className="flex items-center justify-between p-4 bg-slate-900 border border-slate-700 rounded-xl hover:border-slate-600 transition-all">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{action.icon}</span>
                    <span className="text-white font-medium text-sm">{action.name}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-yellow-400 font-bold text-sm">{action.cost}</span>
                    <Button size="sm" className="bg-purple-600 hover:bg-purple-700 text-xs h-7">Use</Button>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* TIP Tab */}
          <TabsContent value="tip" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-slate-900 border-slate-700">
                <CardHeader><CardTitle className="text-white">💝 Send a Tip</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-slate-400 text-sm mb-2 block">Recipient username or address</label>
                    <input
                      value={tipTarget}
                      onChange={e => setTipTarget(e.target.value)}
                      placeholder="@username or SKY444_address"
                      className="w-full bg-slate-800 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 text-sm mb-2 block">Amount (SKY444)</label>
                    <div className="flex gap-2 mb-3">
                      {[5, 10, 25, 50, 100].map(v => (
                        <button key={v} onClick={() => setTipAmount(v)}
                          className={`px-3 py-1.5 rounded-lg text-sm font-bold transition-all ${tipAmount === v ? "bg-purple-600 text-white" : "bg-slate-700 text-slate-300 hover:bg-slate-600"}`}>
                          {v}
                        </button>
                      ))}
                    </div>
                    <input type="number" value={tipAmount} onChange={e => setTipAmount(Number(e.target.value))} min={1}
                      className="w-full bg-slate-800 border border-slate-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500 text-sm" />
                  </div>
                  <div className="bg-slate-800/50 rounded-xl p-3 text-sm space-y-1">
                    <div className="flex justify-between text-slate-400"><span>Tip amount</span><span className="text-white">{tipAmount} SKY444</span></div>
                    <div className="flex justify-between text-slate-400"><span>Creator receives (70%)</span><span className="text-green-400">{Math.floor(tipAmount * 0.7)} SKY444</span></div>
                    <div className="flex justify-between text-slate-400"><span>Platform fee (30%)</span><span className="text-slate-500">{Math.ceil(tipAmount * 0.3)} SKY444</span></div>
                  </div>
                  {!tipSent ? (
                    <Button onClick={() => tipTarget && setTipSent(true)} className="w-full bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 font-bold">
                      💝 Send Tip
                    </Button>
                  ) : (
                    <div className="text-center">
                      <div className="text-2xl mb-2">✅</div>
                      <div className="text-green-400 font-bold">Tip sent! {Math.floor(tipAmount * 0.7)} SKY444 delivered</div>
                      <Button onClick={() => { setTipSent(false); setTipTarget(""); }} variant="ghost" className="mt-2 text-slate-400">Send another</Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-slate-900 border-slate-700">
                <CardHeader><CardTitle className="text-white">🌍 Tip Charity</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  {["🌾 End World Hunger", "📚 Education for All", "🌍 Climate Action", "🏠 Homes for All", "💧 Clean Water", "🐾 Animal Rescue"].map(cause => (
                    <div key={cause} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-xl">
                      <span className="text-white text-sm">{cause}</span>
                      <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-xs h-7">Donate</Button>
                    </div>
                  ))}
                  <p className="text-slate-500 text-xs mt-2">Donating to charity earns you +20 SKY444 bonus per donation!</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* HISTORY Tab */}
          <TabsContent value="history" className="mt-4">
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader><CardTitle className="text-white">📋 Recent Transactions</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                {MOCK_TRANSACTIONS.map((tx, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors">
                    <span className="text-2xl">{tx.icon}</span>
                    <div className="flex-1">
                      <div className="text-white text-sm font-medium">{tx.desc}</div>
                      <div className="text-slate-500 text-xs">{tx.time}</div>
                    </div>
                    <span className={`font-black text-sm ${tx.amount.startsWith("+") ? "text-green-400" : "text-red-400"}`}>
                      {tx.amount} SKY444
                    </span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

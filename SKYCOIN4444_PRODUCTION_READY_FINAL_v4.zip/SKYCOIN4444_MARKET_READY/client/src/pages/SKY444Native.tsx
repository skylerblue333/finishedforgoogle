import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

function useLivePrice() {
  const [price, setPrice] = useState(0.0444);
  const [change, setChange] = useState(4.44);
  const [volume, setVolume] = useState(4444444);
  useEffect(() => {
    const i = setInterval(() => {
      setPrice(p => Math.max(0.001, p * (1 + (Math.random() - 0.48) * 0.02)));
      setChange(c => Math.max(-20, Math.min(50, c + (Math.random() - 0.5) * 0.4)));
      setVolume(v => v + Math.floor(Math.random() * 10000 - 5000));
    }, 3000);
    return () => clearInterval(i);
  }, []);
  return { price, change, volume };
}

const BRIDGE_CHAINS = [
  { name: "Ethereum", symbol: "ETH", icon: "⟠", eta: "Q3 2026", color: "from-blue-500 to-indigo-600", chainId: 1 },
  { name: "Solana", symbol: "SOL", icon: "◎", eta: "Q3 2026", color: "from-purple-500 to-violet-600", chainId: 101 },
  { name: "BNB Chain", symbol: "BNB", icon: "⬡", eta: "Q4 2026", color: "from-yellow-500 to-amber-600", chainId: 56 },
  { name: "Polygon", symbol: "MATIC", icon: "⬟", eta: "Q4 2026", color: "from-violet-500 to-purple-600", chainId: 137 },
  { name: "Base", symbol: "BASE", icon: "🔵", eta: "Q1 2027", color: "from-blue-400 to-sky-600", chainId: 8453 },
];

const STAKING_TIERS = [
  { name: "Bronze", icon: "🥉", min: 100, lock: "7 days", apy: 15, color: "from-amber-700 to-amber-600" },
  { name: "Silver", icon: "🥈", min: 1000, lock: "30 days", apy: 25, color: "from-slate-400 to-slate-300" },
  { name: "Gold", icon: "🥇", min: 5000, lock: "90 days", apy: 35, color: "from-yellow-500 to-yellow-400" },
  { name: "Diamond", icon: "💎", min: 25000, lock: "180 days", apy: 45, color: "from-cyan-500 to-blue-500" },
  { name: "SKY Elite", icon: "🌟", min: 100000, lock: "365 days", apy: 60, color: "from-purple-500 to-yellow-500" },
];

export default function SKY444Native() {
  const { price, change, volume } = useLivePrice();
  const [stakeAmount, setStakeAmount] = useState(100);
  const [selectedTier, setSelectedTier] = useState(0);
  const [swapFrom, setSwapFrom] = useState("USD");
  const [swapAmount, setSwapAmount] = useState(100);
  const [walletAddress] = useState("SKY444_A3F8C2D1E9B7F4A2C6D8E1F3A5B7C9D2E4F6A8B0");
  const [balance] = useState(1247);

  const swapRate = swapFrom === "USD" ? 1 / price : price;
  const receiveAmount = swapAmount * swapRate * 0.997;
  const selectedTierData = STAKING_TIERS[selectedTier];
  const projectedReward = stakeAmount * (selectedTierData.apy / 100) * (parseInt(selectedTierData.lock) / 365);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-yellow-950/10 to-slate-950 p-4">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* Header */}
        <div className="text-center py-6">
          <div className="flex items-center justify-center gap-3 mb-3">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-yellow-400 to-purple-600 flex items-center justify-center text-2xl font-black text-white shadow-lg shadow-purple-500/30">S</div>
            <div className="text-left">
              <h1 className="text-3xl font-black text-white">SKY444 Token</h1>
              <p className="text-slate-400 text-sm">Native Crypto — No Coinbase Required</p>
            </div>
          </div>
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <div className="bg-slate-900 border border-slate-700 rounded-2xl px-6 py-3 text-center">
              <div className="text-3xl font-black text-yellow-400">${price.toFixed(4)}</div>
              <div className={`text-sm font-bold ${change >= 0 ? "text-green-400" : "text-red-400"}`}>
                {change >= 0 ? "▲" : "▼"} {Math.abs(change).toFixed(2)}% (24h)
              </div>
            </div>
            <div className="bg-slate-900 border border-slate-700 rounded-2xl px-6 py-3 text-center">
              <div className="text-2xl font-black text-purple-400">${(volume).toLocaleString()}</div>
              <div className="text-slate-400 text-sm">24h Volume</div>
            </div>
            <div className="bg-slate-900 border border-slate-700 rounded-2xl px-6 py-3 text-center">
              <div className="text-2xl font-black text-emerald-400">${(price * 88888888).toLocaleString(undefined, { maximumFractionDigits: 0 })}</div>
              <div className="text-slate-400 text-sm">Market Cap</div>
            </div>
          </div>
        </div>

        {/* Wallet Card */}
        <Card className="bg-gradient-to-br from-slate-900 to-purple-950/30 border border-purple-800/30">
          <CardContent className="p-6">
            <div className="flex items-start justify-between flex-wrap gap-4">
              <div>
                <div className="text-slate-400 text-sm mb-1">Your Wallet</div>
                <div className="text-white font-mono text-sm bg-slate-800 px-3 py-1.5 rounded-lg">{walletAddress.slice(0, 20)}...{walletAddress.slice(-8)}</div>
              </div>
              <div className="text-right">
                <div className="text-slate-400 text-sm mb-1">Balance</div>
                <div className="text-3xl font-black text-yellow-400">{balance.toLocaleString()} SKY444</div>
                <div className="text-slate-400 text-sm">${(balance * price).toFixed(2)} USD</div>
              </div>
            </div>
            <div className="flex gap-3 mt-4">
              <Button className="flex-1 bg-purple-600 hover:bg-purple-700 font-bold">📤 Send</Button>
              <Button className="flex-1 bg-slate-700 hover:bg-slate-600 font-bold">📥 Receive</Button>
              <Button className="flex-1 bg-yellow-600 hover:bg-yellow-700 font-bold">🔄 Swap</Button>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="swap" className="w-full">
          <TabsList className="bg-slate-900 border border-slate-700 w-full grid grid-cols-4">
            <TabsTrigger value="swap">🔄 Swap</TabsTrigger>
            <TabsTrigger value="stake">🏦 Stake</TabsTrigger>
            <TabsTrigger value="bridge">🌉 Bridge</TabsTrigger>
            <TabsTrigger value="tokenomics">📊 Tokenomics</TabsTrigger>
          </TabsList>

          {/* SWAP */}
          <TabsContent value="swap" className="mt-4">
            <Card className="bg-slate-900 border-slate-700 max-w-md mx-auto">
              <CardHeader><CardTitle className="text-white">🔄 Native DEX Swap</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-slate-800 rounded-xl p-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-slate-400 text-sm">From</span>
                    <span className="text-slate-400 text-sm">Balance: {swapFrom === "SKY444" ? balance : "∞"}</span>
                  </div>
                  <div className="flex gap-3 items-center">
                    <select value={swapFrom} onChange={e => setSwapFrom(e.target.value)}
                      className="bg-slate-700 text-white rounded-lg px-3 py-2 text-sm font-bold border border-slate-600">
                      <option>USD</option>
                      <option>SKY444</option>
                      <option>BTC</option>
                      <option>ETH</option>
                      <option>SOL</option>
                    </select>
                    <input type="number" value={swapAmount} onChange={e => setSwapAmount(Number(e.target.value))} min={1}
                      className="flex-1 bg-transparent text-white text-xl font-black focus:outline-none text-right" />
                  </div>
                </div>
                <div className="text-center text-slate-500">⇅</div>
                <div className="bg-slate-800 rounded-xl p-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-slate-400 text-sm">To</span>
                    <span className="text-slate-400 text-sm">Rate: 1 {swapFrom} = {swapRate.toFixed(4)} {swapFrom === "SKY444" ? "USD" : "SKY444"}</span>
                  </div>
                  <div className="flex gap-3 items-center">
                    <div className="bg-slate-700 text-yellow-400 rounded-lg px-3 py-2 text-sm font-black border border-slate-600">
                      {swapFrom === "SKY444" ? "USD" : "SKY444"}
                    </div>
                    <div className="flex-1 text-yellow-400 text-xl font-black text-right">{receiveAmount.toFixed(4)}</div>
                  </div>
                </div>
                <div className="text-xs text-slate-500 space-y-1">
                  <div className="flex justify-between"><span>Swap fee</span><span>0.3%</span></div>
                  <div className="flex justify-between"><span>Price impact</span><span>&lt;0.1%</span></div>
                  <div className="flex justify-between"><span>Min received</span><span>{(receiveAmount * 0.995).toFixed(4)}</span></div>
                </div>
                <Button className="w-full bg-gradient-to-r from-yellow-500 to-purple-600 hover:from-yellow-600 hover:to-purple-700 font-black text-lg h-12">
                  Swap Now
                </Button>
                <p className="text-center text-slate-500 text-xs">Powered by SKY444 Native DEX — No Coinbase, No Uniswap</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* STAKE */}
          <TabsContent value="stake" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h3 className="text-white font-black text-lg">Choose Staking Tier</h3>
                {STAKING_TIERS.map((tier, i) => (
                  <motion.div key={tier.name} whileHover={{ scale: 1.01 }}
                    onClick={() => setSelectedTier(i)}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${selectedTier === i ? "border-purple-500 bg-purple-900/20" : "border-slate-700 bg-slate-900/50 hover:border-slate-600"}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{tier.icon}</span>
                        <div>
                          <div className="text-white font-bold">{tier.name}</div>
                          <div className="text-slate-400 text-xs">Min: {tier.min.toLocaleString()} SKY444 · Lock: {tier.lock}</div>
                        </div>
                      </div>
                      <div className="text-green-400 font-black text-xl">{tier.apy}%</div>
                    </div>
                  </motion.div>
                ))}
              </div>
              <Card className="bg-slate-900 border-slate-700 h-fit">
                <CardHeader><CardTitle className="text-white">Stake SKY444</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-slate-400 text-sm mb-2 block">Amount to Stake</label>
                    <input type="number" value={stakeAmount} onChange={e => setStakeAmount(Number(e.target.value))} min={selectedTierData.min}
                      className="w-full bg-slate-800 border border-slate-600 rounded-xl px-4 py-3 text-white text-xl font-black focus:outline-none focus:border-purple-500" />
                    <div className="flex gap-2 mt-2">
                      {[100, 500, 1000, 5000].map(v => (
                        <button key={v} onClick={() => setStakeAmount(v)}
                          className="px-2 py-1 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-lg text-xs font-bold transition-all">
                          {v.toLocaleString()}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="bg-slate-800/50 rounded-xl p-4 space-y-2 text-sm">
                    <div className="flex justify-between"><span className="text-slate-400">Tier</span><span className="text-white font-bold">{selectedTierData.icon} {selectedTierData.name}</span></div>
                    <div className="flex justify-between"><span className="text-slate-400">APY</span><span className="text-green-400 font-black">{selectedTierData.apy}%</span></div>
                    <div className="flex justify-between"><span className="text-slate-400">Lock Period</span><span className="text-white">{selectedTierData.lock}</span></div>
                    <div className="flex justify-between"><span className="text-slate-400">Projected Reward</span><span className="text-yellow-400 font-black">+{projectedReward.toFixed(0)} SKY444</span></div>
                    <div className="flex justify-between"><span className="text-slate-400">Reward in USD</span><span className="text-yellow-400">${(projectedReward * price).toFixed(2)}</span></div>
                  </div>
                  <Button disabled={stakeAmount < selectedTierData.min} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 font-black h-12">
                    🏦 Stake {stakeAmount.toLocaleString()} SKY444
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* BRIDGE */}
          <TabsContent value="bridge" className="mt-4">
            <div className="text-center mb-8">
              <Badge className="bg-orange-600/20 text-orange-400 border border-orange-600/30 text-sm px-4 py-1 mb-4">🚧 Coming Soon</Badge>
              <h3 className="text-2xl font-black text-white">Multi-Chain Bridge</h3>
              <p className="text-slate-400 mt-2 max-w-xl mx-auto">SKY444 will be bridgeable to all major blockchains. No Coinbase required — our native bridge handles everything.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {BRIDGE_CHAINS.map(chain => (
                <motion.div key={chain.name} whileHover={{ scale: 1.02 }}
                  className="bg-slate-900 border border-slate-700 rounded-2xl p-5 relative overflow-hidden">
                  <div className={`absolute inset-0 bg-gradient-to-br ${chain.color} opacity-5`} />
                  <div className="relative">
                    <div className="flex items-center gap-3 mb-4">
                      <span className="text-4xl">{chain.icon}</span>
                      <div>
                        <div className="text-white font-black text-lg">{chain.name}</div>
                        <div className="text-slate-400 text-sm">{chain.symbol}</div>
                      </div>
                      <Badge className="ml-auto bg-orange-600/20 text-orange-400 border border-orange-600/30 text-xs">Soon</Badge>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between"><span className="text-slate-400">Chain ID</span><span className="text-white">{chain.chainId}</span></div>
                      <div className="flex justify-between"><span className="text-slate-400">Launch ETA</span><span className="text-yellow-400 font-bold">{chain.eta}</span></div>
                      <div className="flex justify-between"><span className="text-slate-400">Bridge Fee</span><span className="text-white">0.1%</span></div>
                    </div>
                    <Button disabled className="w-full mt-4 bg-slate-700 text-slate-400 cursor-not-allowed">
                      Coming {chain.eta}
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
            <div className="mt-6 bg-slate-900 border border-yellow-800/30 rounded-2xl p-6 text-center">
              <div className="text-2xl mb-2">📧</div>
              <div className="text-white font-bold mb-2">Get notified when bridges launch</div>
              <div className="flex gap-3 max-w-sm mx-auto">
                <input placeholder="your@email.com" className="flex-1 bg-slate-800 border border-slate-600 rounded-xl px-4 py-2 text-white text-sm focus:outline-none focus:border-yellow-500" />
                <Button className="bg-yellow-600 hover:bg-yellow-700 font-bold">Notify Me</Button>
              </div>
            </div>
          </TabsContent>

          {/* TOKENOMICS */}
          <TabsContent value="tokenomics" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-slate-900 border-slate-700">
                <CardHeader><CardTitle className="text-white">📊 Token Distribution</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { label: "Community Rewards", pct: 40, color: "bg-purple-500" },
                    { label: "Platform Treasury", pct: 20, color: "bg-blue-500" },
                    { label: "Team (2yr vesting)", pct: 15, color: "bg-yellow-500" },
                    { label: "Staking Pool", pct: 15, color: "bg-green-500" },
                    { label: "Charity Reserve", pct: 5, color: "bg-emerald-500" },
                    { label: "Initial Liquidity", pct: 5, color: "bg-cyan-500" },
                  ].map(item => (
                    <div key={item.label}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-slate-300">{item.label}</span>
                        <span className="text-white font-bold">{item.pct}%</span>
                      </div>
                      <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                        <div className={`h-full ${item.color} rounded-full`} style={{ width: `${item.pct}%` }} />
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
              <Card className="bg-slate-900 border-slate-700">
                <CardHeader><CardTitle className="text-white">🔢 Token Stats</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { label: "Token Name", value: "SKYCOIN4444" },
                    { label: "Symbol", value: "SKY444" },
                    { label: "Total Supply", value: "444,444,444" },
                    { label: "Circulating", value: "88,888,888" },
                    { label: "Decimals", value: "18" },
                    { label: "Current Price", value: `$${price.toFixed(4)}` },
                    { label: "Market Cap", value: `$${(price * 88888888).toLocaleString(undefined, { maximumFractionDigits: 0 })}` },
                    { label: "All-Time High", value: "$0.0888" },
                    { label: "Chain", value: "SKY444 Native + Multi-chain (soon)" },
                    { label: "Consensus", value: "Proof of Engagement (PoE)" },
                  ].map(item => (
                    <div key={item.label} className="flex justify-between py-2 border-b border-slate-800 text-sm">
                      <span className="text-slate-400">{item.label}</span>
                      <span className="text-white font-semibold">{item.value}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

import { useState } from "react";
import { Link } from "wouter";
import { Code2, Key, Book, Zap, Copy, CheckCircle, ArrowRight, Terminal, Globe, Shield } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const ENDPOINTS = [
  { method: "GET",    path: "/api/v1/feed",           desc: "Get personalized social feed",           auth: true,  cat: "Social"  },
  { method: "POST",   path: "/api/v1/posts",           desc: "Create a new post",                      auth: true,  cat: "Social"  },
  { method: "GET",    path: "/api/v1/users/:id",       desc: "Get user profile",                       auth: false, cat: "Users"   },
  { method: "POST",   path: "/api/v1/follow",          desc: "Follow a user",                          auth: true,  cat: "Users"   },
  { method: "GET",    path: "/api/v1/wallet/balance",  desc: "Get wallet balance",                     auth: true,  cat: "Crypto"  },
  { method: "POST",   path: "/api/v1/stake",           desc: "Stake SKY444 tokens",                    auth: true,  cat: "Crypto"  },
  { method: "POST",   path: "/api/v1/swap",            desc: "Swap tokens",                            auth: true,  cat: "Crypto"  },
  { method: "GET",    path: "/api/v1/trending",        desc: "Get trending topics and posts",          auth: false, cat: "Social"  },
  { method: "POST",   path: "/api/v1/stream/start",    desc: "Start a live stream",                    auth: true,  cat: "Stream"  },
  { method: "GET",    path: "/api/v1/community/:id",   desc: "Get community details",                  auth: false, cat: "Social"  },
  { method: "POST",   path: "/api/v1/ai/chat",         desc: "Chat with AI assistant",                 auth: true,  cat: "AI"      },
  { method: "GET",    path: "/api/v1/marketplace",     desc: "Browse marketplace listings",            auth: false, cat: "Market"  },
];

const CATS = ["All", "Social", "Users", "Crypto", "Stream", "AI", "Market"];

const METHOD_COLOR: Record<string, string> = {
  GET:    "bg-green-500/20 text-green-400 border-green-500/30",
  POST:   "bg-blue-500/20 text-blue-400 border-blue-500/30",
  PUT:    "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  DELETE: "bg-red-500/20 text-red-400 border-red-500/30",
};

const CODE_EXAMPLE = `// Authenticate with Bearer token
const response = await fetch('https://shadowchat.app/api/v1/feed', {
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  }
});

const { posts, nextCursor } = await response.json();
console.log(posts);`;

export default function ApiDocs() {
  const [cat, setCat] = useState("All");
  const [copied, setCopied] = useState(false);

  const filtered = ENDPOINTS.filter(e => cat === "All" || e.cat === cat);

  const handleCopy = () => {
    navigator.clipboard.writeText(CODE_EXAMPLE);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="container py-8 max-w-4xl animate-page-in">
      <PageHeader
        backHref="/developer-protocol"
        icon={Code2}
        title="API Documentation"
        subtitle="Integrate ShadowChat into your apps with our REST and tRPC APIs"
        actions={
          <Link href="/api-keys">
            <Button className="btn-primary gap-2">
              <Key className="w-4 h-4" /> Get API Key
            </Button>
          </Link>
        }
      />

      {/* Quick start */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        {[
          { icon: Key,      title: "Authentication",  desc: "Bearer token auth",    href: "/api-keys"           },
          { icon: Book,     title: "REST API",        desc: "305 endpoints",        href: "/developer-protocol" },
          { icon: Terminal, title: "tRPC Client",     desc: "Type-safe SDK",        href: "/embed-sdk"          },
        ].map(card => (
          <Link key={card.title} href={card.href}>
            <div className="card p-4 flex items-center gap-3 hover:border-slate-700/60 active:scale-[0.98] transition-all cursor-pointer group">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                <card.icon className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm">{card.title}</div>
                <div className="text-xs text-muted-foreground">{card.desc}</div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-primary transition-colors shrink-0" />
            </div>
          </Link>
        ))}
      </div>

      {/* Code example */}
      <div className="card p-5 mb-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-sm flex items-center gap-2">
            <Terminal className="w-4 h-4 text-cyan-400" /> Quick Start
          </h3>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs text-muted-foreground hover:text-foreground bg-secondary/50 hover:bg-secondary transition-all active:scale-95"
          >
            {copied ? <CheckCircle className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? "Copied!" : "Copy"}
          </button>
        </div>
        <pre className="bg-black/40 rounded-xl p-4 text-xs font-mono text-green-400 overflow-x-auto border border-slate-700/40">
          {CODE_EXAMPLE}
        </pre>
      </div>

      {/* Category filter */}
      <div className="flex gap-1.5 flex-wrap mb-4">
        {CATS.map(c => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all active:scale-[0.97] ${
              cat === c
                ? "bg-primary text-primary-foreground"
                : "bg-secondary/50 text-muted-foreground hover:bg-secondary hover:text-foreground border border-slate-700/40"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Endpoints */}
      <div className="space-y-1.5">
        {filtered.map((ep, i) => (
          <div key={i} className="card p-3.5 flex items-center gap-3 hover:border-slate-700/60 transition-all">
            <span className={`text-[10px] font-mono font-bold px-2 py-1 rounded border shrink-0 ${METHOD_COLOR[ep.method]}`}>
              {ep.method}
            </span>
            <code className="text-xs font-mono text-foreground/80 flex-1 min-w-0 truncate">{ep.path}</code>
            <span className="text-xs text-muted-foreground hidden sm:block flex-1 min-w-0 truncate">{ep.desc}</span>
            <div className="flex items-center gap-1.5 shrink-0">
              {ep.auth && (
                <span className="flex items-center gap-1 text-[10px] text-yellow-400">
                  <Shield className="w-3 h-3" /> Auth
                </span>
              )}
              <Badge variant="outline" className="text-[10px]">{ep.cat}</Badge>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 card p-5 flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-sm">Full API Reference</h3>
          <p className="text-xs text-muted-foreground">305 endpoints with request/response schemas</p>
        </div>
        <Link href="/developer-protocol">
          <Button className="btn-primary gap-2 text-xs">
            <Globe className="w-3.5 h-3.5" /> Full Docs <ArrowRight className="w-3.5 h-3.5" />
          </Button>
        </Link>
      </div>
    </div>
  );
}

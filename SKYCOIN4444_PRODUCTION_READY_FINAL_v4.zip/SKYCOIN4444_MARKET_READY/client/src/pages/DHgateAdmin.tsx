import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const CATEGORIES = ["All", "Watches", "Bags", "Belts", "Shoes", "Pants", "Shirts"];

// Mock product data matching the seeder
const PRODUCTS = [
  { sku:"DHW001", name:"Luxury Chronograph Men's Watch", category:"Watches", cost:28.50, markup:44, price:72.50, stock:500, sold:12400, rating:4.8, featured:true, aiRepost:true, image:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300" },
  { sku:"DHW002", name:"Women's Diamond Bezel Quartz Watch", category:"Watches", cost:18.00, markup:44, price:62.00, stock:800, sold:9800, rating:4.7, featured:true, aiRepost:true, image:"https://images.unsplash.com/photo-1548169874-53e85f753f1e?w=300" },
  { sku:"DHW003", name:"Smart Sport Watch GPS", category:"Watches", cost:35.00, markup:44, price:79.00, stock:300, sold:7200, rating:4.6, featured:false, aiRepost:true, image:"https://images.unsplash.com/photo-1544117519-31a4b719223d?w=300" },
  { sku:"DHW004", name:"Skeleton Mechanical Watch", category:"Watches", cost:42.00, markup:44, price:86.00, stock:200, sold:5600, rating:4.9, featured:true, aiRepost:true, image:"https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=300" },
  { sku:"DHB001", name:"Designer Tote Bag Premium PU", category:"Bags", cost:22.00, markup:44, price:66.00, stock:600, sold:18900, rating:4.7, featured:true, aiRepost:true, image:"https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=300" },
  { sku:"DHB002", name:"Men's Crossbody Messenger Bag", category:"Bags", cost:16.50, markup:44, price:60.50, stock:400, sold:11200, rating:4.6, featured:false, aiRepost:true, image:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300" },
  { sku:"DHB003", name:"Mini Quilted Chain Shoulder Bag", category:"Bags", cost:14.00, markup:44, price:58.00, stock:700, sold:22100, rating:4.8, featured:true, aiRepost:true, image:"https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=300" },
  { sku:"DHBL001", name:"Men's Genuine Leather Belt Gold", category:"Belts", cost:8.50, markup:44, price:52.50, stock:1000, sold:31500, rating:4.8, featured:true, aiRepost:true, image:"https://images.unsplash.com/photo-1624222247344-550fb60583dc?w=300" },
  { sku:"DHBL002", name:"Designer Logo Belt Reversible", category:"Belts", cost:12.00, markup:44, price:56.00, stock:800, sold:19800, rating:4.7, featured:true, aiRepost:true, image:"https://images.unsplash.com/photo-1585386959984-a4155224a1ad?w=300" },
  { sku:"DHS001", name:"Men's Running Sneakers Air Cushion", category:"Shoes", cost:24.00, markup:44, price:68.00, stock:500, sold:14600, rating:4.7, featured:true, aiRepost:true, image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=300" },
  { sku:"DHS002", name:"Women's Platform Heels Block", category:"Shoes", cost:19.00, markup:44, price:63.00, stock:400, sold:9200, rating:4.6, featured:true, aiRepost:true, image:"https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=300" },
  { sku:"DHS003", name:"Classic Canvas Low-Top Sneakers", category:"Shoes", cost:11.00, markup:44, price:55.00, stock:900, sold:38700, rating:4.8, featured:false, aiRepost:true, image:"https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=300" },
  { sku:"DHP001", name:"Men's Slim Fit Chino Pants", category:"Pants", cost:14.00, markup:44, price:58.00, stock:600, sold:16400, rating:4.7, featured:true, aiRepost:true, image:"https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=300" },
  { sku:"DHP002", name:"Women's High-Waist Yoga Leggings", category:"Pants", cost:9.50, markup:44, price:53.50, stock:1000, sold:44200, rating:4.9, featured:true, aiRepost:true, image:"https://images.unsplash.com/photo-1506629082955-511b1aa562c8?w=300" },
  { sku:"DHSH001", name:"Men's Premium Polo Shirt", category:"Shirts", cost:10.00, markup:44, price:54.00, stock:800, sold:28600, rating:4.8, featured:true, aiRepost:true, image:"https://images.unsplash.com/photo-1586363104862-3a5e2ab60d99?w=300" },
  { sku:"DHSH002", name:"Women's Oversized Graphic T-Shirt", category:"Shirts", cost:7.50, markup:44, price:51.50, stock:700, sold:19900, rating:4.7, featured:true, aiRepost:true, image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300" },
  { sku:"DHSH003", name:"Men's Slim Fit Dress Shirt Oxford", category:"Shirts", cost:12.00, markup:44, price:56.00, stock:600, sold:14300, rating:4.7, featured:false, aiRepost:true, image:"https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=300" },
  { sku:"DHSH004", name:"Women's Satin Blouse V-Neck", category:"Shirts", cost:11.00, markup:44, price:55.00, stock:500, sold:17600, rating:4.8, featured:true, aiRepost:true, image:"https://images.unsplash.com/photo-1594938298603-c8148c4b4f7b?w=300" },
];

export default function DHgateAdmin() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [globalMarkup, setGlobalMarkup] = useState(44);
  const [products, setProducts] = useState(PRODUCTS);
  const [search, setSearch] = useState("");
  const [editingMarkup, setEditingMarkup] = useState<string | null>(null);
  const [tempMarkup, setTempMarkup] = useState("");

  const filtered = products.filter(p =>
    (activeCategory === "All" || p.category === activeCategory) &&
    (p.name.toLowerCase().includes(search.toLowerCase()) || p.sku.toLowerCase().includes(search.toLowerCase()))
  );

  const totalRevenue = products.reduce((s, p) => s + p.price * Math.floor(p.sold * 0.01), 0);
  const totalProfit = products.reduce((s, p) => s + p.markup * Math.floor(p.sold * 0.01), 0);

  const applyGlobalMarkup = () => {
    setProducts(prev => prev.map(p => ({ ...p, markup: globalMarkup, price: parseFloat((p.cost + globalMarkup).toFixed(2)) })));
  };

  const updateProductMarkup = (sku: string, newMarkup: number) => {
    setProducts(prev => prev.map(p => p.sku === sku
      ? { ...p, markup: newMarkup, price: parseFloat((p.cost + newMarkup).toFixed(2)) }
      : p
    ));
    setEditingMarkup(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-black text-white">🛒 DHgate Product Manager</h1>
            <p className="text-slate-400 text-sm mt-1">All orders route to your account • AI auto-repost active</p>
          </div>
          <div className="flex items-center gap-3">
            <Badge className="bg-green-600/20 text-green-400 border border-green-600/30">● AI Repost Active</Badge>
            <Badge className="bg-blue-600/20 text-blue-400 border border-blue-600/30">All Orders → You</Badge>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Total Products", value: products.length, icon: "📦", color: "text-blue-400" },
            { label: "Total Items Sold", value: products.reduce((s,p) => s+p.sold, 0).toLocaleString(), icon: "📈", color: "text-green-400" },
            { label: "Est. Revenue", value: `$${totalRevenue.toLocaleString()}`, icon: "💰", color: "text-yellow-400" },
            { label: "Est. Profit ($44 markup)", value: `$${totalProfit.toLocaleString()}`, icon: "💎", color: "text-purple-400" },
          ].map((stat, i) => (
            <Card key={i} className="bg-slate-900 border-slate-700">
              <CardContent className="p-4">
                <div className="text-2xl mb-1">{stat.icon}</div>
                <div className={`text-xl font-black ${stat.color}`}>{stat.value}</div>
                <div className="text-slate-400 text-xs">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Global Markup Control */}
        <Card className="bg-slate-900 border-yellow-800/30">
          <CardContent className="p-4">
            <div className="flex items-center gap-4 flex-wrap">
              <div className="text-white font-bold">💲 Global Base Markup:</div>
              <div className="flex items-center gap-2">
                <span className="text-slate-400 text-sm">DHgate Cost +</span>
                <Input
                  type="number"
                  value={globalMarkup}
                  onChange={e => setGlobalMarkup(Number(e.target.value))}
                  className="w-24 bg-slate-800 border-slate-600 text-white text-center font-black"
                />
                <span className="text-yellow-400 font-bold">= Selling Price</span>
              </div>
              <Button onClick={applyGlobalMarkup} className="bg-yellow-600 hover:bg-yellow-700 font-bold">
                Apply to All Products
              </Button>
              <p className="text-slate-500 text-xs">You can also set per-product markup by clicking the price</p>
            </div>
          </CardContent>
        </Card>

        {/* Search + Category Filter */}
        <div className="flex gap-3 flex-wrap items-center">
          <Input
            placeholder="Search products..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="bg-slate-800 border-slate-600 text-white w-64"
          />
          <div className="flex gap-2 flex-wrap">
            {CATEGORIES.map(cat => (
              <button key={cat} onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-sm font-bold transition-all ${
                  activeCategory === cat ? "bg-purple-600 text-white" : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                }`}>
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map((product, i) => (
            <motion.div key={product.sku} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>
              <Card className="bg-slate-900 border-slate-700 hover:border-slate-600 transition-all overflow-hidden">
                {/* Product Image */}
                <div className="relative">
                  <img src={product.image} alt={product.name} className="w-full h-44 object-cover" onError={e => { (e.target as HTMLImageElement).src = "https://via.placeholder.com/300x200?text=Product+Image"; }} />
                  <div className="absolute top-2 left-2 flex gap-1">
                    {product.featured && <Badge className="bg-yellow-500 text-black text-xs">⭐ Featured</Badge>}
                    {product.aiRepost && <Badge className="bg-purple-600 text-white text-xs">🤖 AI</Badge>}
                  </div>
                  <div className="absolute top-2 right-2">
                    <Badge className="bg-slate-900/80 text-white text-xs">{product.category}</Badge>
                  </div>
                </div>

                <CardContent className="p-3">
                  <div className="text-white font-bold text-sm mb-1 line-clamp-2">{product.name}</div>
                  <div className="text-slate-500 text-xs mb-2">SKU: {product.sku}</div>

                  {/* Pricing */}
                  <div className="bg-slate-800/50 rounded-lg p-2 mb-3 space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">DHgate Cost</span>
                      <span className="text-slate-300">${product.cost}</span>
                    </div>
                    <div className="flex justify-between text-xs items-center">
                      <span className="text-slate-400">Markup</span>
                      {editingMarkup === product.sku ? (
                        <div className="flex items-center gap-1">
                          <input
                            type="number"
                            value={tempMarkup}
                            onChange={e => setTempMarkup(e.target.value)}
                            className="w-16 bg-slate-700 text-white text-xs text-center rounded px-1 py-0.5"
                            autoFocus
                          />
                          <button onClick={() => updateProductMarkup(product.sku, Number(tempMarkup))} className="text-green-400 text-xs">✓</button>
                          <button onClick={() => setEditingMarkup(null)} className="text-red-400 text-xs">✗</button>
                        </div>
                      ) : (
                        <button onClick={() => { setEditingMarkup(product.sku); setTempMarkup(String(product.markup)); }}
                          className="text-yellow-400 font-bold hover:underline">+${product.markup}</button>
                      )}
                    </div>
                    <div className="flex justify-between text-xs border-t border-slate-700 pt-1">
                      <span className="text-white font-bold">Sell Price</span>
                      <span className="text-green-400 font-black">${product.price}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">Profit/unit</span>
                      <span className="text-purple-400 font-bold">${product.markup}</span>
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="flex justify-between text-xs text-slate-400 mb-3">
                    <span>⭐ {product.rating}</span>
                    <span>📦 {product.stock} stock</span>
                    <span>✅ {product.sold.toLocaleString()} sold</span>
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" className="flex-1 bg-purple-600 hover:bg-purple-700 text-xs h-7">
                      Edit
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700 text-xs h-7">
                      {product.aiRepost ? "🤖 Active" : "Enable AI"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Order Routing Info */}
        <Card className="bg-slate-900 border-emerald-800/30">
          <CardHeader><CardTitle className="text-white text-base">📦 Order Routing Configuration</CardTitle></CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div className="flex justify-between p-2 bg-slate-800/50 rounded-lg">
              <span className="text-slate-400">All Orders Route To</span>
              <span className="text-green-400 font-bold">skyler.spillers (Your Account)</span>
            </div>
            <div className="flex justify-between p-2 bg-slate-800/50 rounded-lg">
              <span className="text-slate-400">AI Auto-Repost Schedule</span>
              <span className="text-purple-400 font-bold">Every 24 hours</span>
            </div>
            <div className="flex justify-between p-2 bg-slate-800/50 rounded-lg">
              <span className="text-slate-400">Top Sellers Reposted</span>
              <span className="text-yellow-400 font-bold">Top 10 by sales volume</span>
            </div>
            <div className="flex justify-between p-2 bg-slate-800/50 rounded-lg">
              <span className="text-slate-400">Base Markup Applied</span>
              <span className="text-white font-bold">+${globalMarkup} on all products</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

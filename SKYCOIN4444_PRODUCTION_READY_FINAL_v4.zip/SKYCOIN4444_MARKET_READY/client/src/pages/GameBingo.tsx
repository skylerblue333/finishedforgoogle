import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { trpc } from "@/lib/trpc";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// ── Types ──────────────────────────────────────────────────────────────────
type BingoCard = number[][];
type MarkedCell = { row: number; col: number };

const BINGO_LETTERS = ["B", "I", "N", "G", "O"];
const CHARITY_CAUSES = [
  { id: "hunger", name: "End World Hunger", icon: "🌾", goal: 50000, raised: 31240 },
  { id: "education", name: "Education for All", icon: "📚", goal: 75000, raised: 48900 },
  { id: "climate", name: "Climate Action", icon: "🌍", goal: 100000, raised: 67800 },
  { id: "shelter", name: "Homeless Shelter", icon: "🏠", goal: 30000, raised: 22100 },
];

// ── Bingo Card Generator ───────────────────────────────────────────────────
function generateBingoCard(): BingoCard {
  const ranges = [[1,15],[16,30],[31,45],[46,60],[61,75]];
  return Array.from({ length: 5 }, (_, col) => {
    const [min, max] = ranges[col];
    const nums = new Set<number>();
    while (nums.size < 5) nums.add(Math.floor(Math.random() * (max - min + 1)) + min);
    const arr = Array.from(nums);
    if (col === 2) arr[2] = 0; // FREE space
    return arr;
  });
}

function checkWin(card: BingoCard, marked: Set<string>): boolean {
  const isMarked = (r: number, c: number) =>
    card[c][r] === 0 || marked.has(`${r}-${c}`);

  // Rows
  for (let r = 0; r < 5; r++)
    if ([0,1,2,3,4].every(c => isMarked(r, c))) return true;
  // Cols
  for (let c = 0; c < 5; c++)
    if ([0,1,2,3,4].every(r => isMarked(r, c))) return true;
  // Diagonals
  if ([0,1,2,3,4].every(i => isMarked(i, i))) return true;
  if ([0,1,2,3,4].every(i => isMarked(i, 4-i))) return true;
  return false;
}

// ── Main Component ─────────────────────────────────────────────────────────
export default function GameBingo() {
  const { toast } = useToast();
  const [card, setCard] = useState<BingoCard>(() => generateBingoCard());
  const [marked, setMarked] = useState<Set<string>>(new Set(["2-2"])); // FREE
  const [calledNumbers, setCalledNumbers] = useState<number[]>([]);
  const [currentCall, setCurrentCall] = useState<number | null>(null);
  const [gameActive, setGameActive] = useState(false);
  const [won, setWon] = useState(false);
  const [skyReward, setSkyReward] = useState(0);
  const [selectedCharity, setSelectedCharity] = useState(CHARITY_CAUSES[0]);
  const [charityPool, setCharityPool] = useState(0);
  const [betAmount, setBetAmount] = useState(10);
  const [playerBalance, setPlayerBalance] = useState(500);
  const [jackpot, setJackpot] = useState(4444);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const allNumbers = Array.from({ length: 75 }, (_, i) => i + 1);

  const startGame = useCallback(() => {
    if (playerBalance < betAmount) {
      toast({ title: "Insufficient SKY444 balance", variant: "destructive" });
      return;
    }
    setPlayerBalance(b => b - betAmount);
    setCharityPool(p => p + Math.floor(betAmount * 0.1)); // 10% to charity
    setCard(generateBingoCard());
    setMarked(new Set(["2-2"]));
    setCalledNumbers([]);
    setCurrentCall(null);
    setWon(false);
    setGameActive(true);
    setSkyReward(0);
    setJackpot(j => j + Math.floor(betAmount * 0.05));
  }, [betAmount, playerBalance, toast]);

  useEffect(() => {
    if (!gameActive || won) return;
    const remaining = allNumbers.filter(n => !calledNumbers.includes(n));
    if (remaining.length === 0) { setGameActive(false); return; }

    intervalRef.current = setInterval(() => {
      const idx = Math.floor(Math.random() * remaining.length);
      const num = remaining[idx];
      setCurrentCall(num);
      setCalledNumbers(prev => [...prev, num]);
    }, 2500);

    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [gameActive, calledNumbers, won]);

  // Auto-mark called numbers
  useEffect(() => {
    if (!currentCall) return;
    const newMarked = new Set(marked);
    for (let c = 0; c < 5; c++) {
      for (let r = 0; r < 5; r++) {
        if (card[c][r] === currentCall) newMarked.add(`${r}-${c}`);
      }
    }
    setMarked(newMarked);
    if (checkWin(card, newMarked)) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setWon(true);
      setGameActive(false);
      const reward = betAmount * 5 + (calledNumbers.length < 20 ? jackpot : 0);
      setSkyReward(reward);
      setPlayerBalance(b => b + reward);
      toast({
        title: "🎉 BINGO! You won!",
        description: `+${reward} SKY444 tokens earned! 10% donated to ${selectedCharity.name}`,
      });
    }
  }, [currentCall]);

  const getLetterForCol = (col: number) => BINGO_LETTERS[col];
  const getColRange = (col: number) => {
    const ranges = [[1,15],[16,30],[31,45],[46,60],[61,75]];
    return ranges[col];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-purple-400">
            🎱 SKYCOIN4444 BINGO
          </h1>
          <p className="text-slate-400 mt-1">Play for SKY444 tokens — 10% of every bet goes to charity</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Charity Panel */}
          <div className="space-y-4">
            <Card className="bg-slate-900 border-purple-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-white text-sm">🌟 Charity Pool</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-black text-yellow-400">{charityPool} SKY444</div>
                <p className="text-slate-400 text-xs mt-1">Accumulated from all bets</p>
                <div className="mt-4 space-y-3">
                  {CHARITY_CAUSES.map(cause => (
                    <div
                      key={cause.id}
                      onClick={() => setSelectedCharity(cause)}
                      className={`p-3 rounded-lg cursor-pointer border transition-all ${
                        selectedCharity.id === cause.id
                          ? "border-purple-500 bg-purple-900/30"
                          : "border-slate-700 bg-slate-800/50 hover:border-slate-600"
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <span>{cause.icon}</span>
                        <span className="text-white text-xs font-semibold">{cause.name}</span>
                      </div>
                      <Progress value={(cause.raised / cause.goal) * 100} className="h-1.5" />
                      <div className="flex justify-between text-xs text-slate-400 mt-1">
                        <span>${cause.raised.toLocaleString()}</span>
                        <span>${cause.goal.toLocaleString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Player Stats */}
            <Card className="bg-slate-900 border-slate-700">
              <CardContent className="pt-4 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 text-sm">Balance</span>
                  <span className="text-yellow-400 font-bold">{playerBalance} SKY444</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 text-sm">Jackpot</span>
                  <span className="text-purple-400 font-bold">{jackpot} SKY444</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 text-sm">Bet</span>
                  <div className="flex gap-1">
                    {[5, 10, 25, 50].map(v => (
                      <button
                        key={v}
                        onClick={() => setBetAmount(v)}
                        className={`px-2 py-0.5 rounded text-xs font-bold transition-all ${
                          betAmount === v
                            ? "bg-purple-600 text-white"
                            : "bg-slate-700 text-slate-300 hover:bg-slate-600"
                        }`}
                      >
                        {v}
                      </button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Center: Bingo Card */}
          <div className="lg:col-span-1">
            {/* Current Call */}
            <div className="text-center mb-4">
              <AnimatePresence mode="wait">
                {currentCall ? (
                  <motion.div
                    key={currentCall}
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    exit={{ scale: 0, opacity: 0 }}
                    className="inline-flex flex-col items-center"
                  >
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-yellow-400 to-purple-600 flex items-center justify-center shadow-lg shadow-purple-500/30">
                      <span className="text-3xl font-black text-white">{currentCall}</span>
                    </div>
                    <span className="text-slate-400 text-xs mt-1">
                      {BINGO_LETTERS[Math.floor((currentCall - 1) / 15)]}-{currentCall}
                    </span>
                  </motion.div>
                ) : (
                  <div className="w-20 h-20 rounded-full bg-slate-800 border-2 border-slate-600 flex items-center justify-center mx-auto">
                    <span className="text-slate-500 text-2xl">?</span>
                  </div>
                )}
              </AnimatePresence>
            </div>

            {/* Bingo Card Grid */}
            <div className="bg-slate-900 rounded-2xl p-4 border border-purple-800/50">
              {/* Column headers */}
              <div className="grid grid-cols-5 gap-1 mb-2">
                {BINGO_LETTERS.map(l => (
                  <div key={l} className="text-center text-purple-400 font-black text-lg">{l}</div>
                ))}
              </div>
              {/* Rows */}
              {[0,1,2,3,4].map(row => (
                <div key={row} className="grid grid-cols-5 gap-1 mb-1">
                  {[0,1,2,3,4].map(col => {
                    const num = card[col][row];
                    const isMarkedCell = num === 0 || marked.has(`${row}-${col}`);
                    const isCurrent = num === currentCall;
                    return (
                      <motion.div
                        key={`${row}-${col}`}
                        animate={isCurrent ? { scale: [1, 1.2, 1] } : {}}
                        className={`
                          aspect-square flex items-center justify-center rounded-lg text-sm font-bold cursor-pointer
                          transition-all duration-300 select-none
                          ${num === 0
                            ? "bg-gradient-to-br from-yellow-500 to-purple-600 text-white text-xs"
                            : isMarkedCell
                            ? "bg-purple-600 text-white shadow-lg shadow-purple-500/40"
                            : isCurrent
                            ? "bg-yellow-500 text-black"
                            : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                          }
                        `}
                      >
                        {num === 0 ? "FREE" : num}
                      </motion.div>
                    );
                  })}
                </div>
              ))}
            </div>

            {/* Controls */}
            <div className="mt-4 space-y-2">
              {!gameActive && !won && (
                <Button
                  onClick={startGame}
                  className="w-full bg-gradient-to-r from-purple-600 to-yellow-500 hover:from-purple-700 hover:to-yellow-600 text-white font-black text-lg h-12"
                >
                  🎱 Play Bingo — {betAmount} SKY444
                </Button>
              )}
              {gameActive && (
                <div className="text-center">
                  <Badge className="bg-green-600 text-white animate-pulse">🎲 Game in Progress...</Badge>
                  <p className="text-slate-400 text-xs mt-1">{calledNumbers.length} numbers called</p>
                </div>
              )}
              {won && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="text-center space-y-3"
                >
                  <div className="text-4xl">🎉</div>
                  <div className="text-2xl font-black text-yellow-400">BINGO! +{skyReward} SKY444</div>
                  <div className="text-sm text-purple-400">
                    {Math.floor(skyReward * 0.1)} SKY444 donated to {selectedCharity.name} {selectedCharity.icon}
                  </div>
                  <Button onClick={startGame} className="w-full bg-purple-600 hover:bg-purple-700">
                    Play Again
                  </Button>
                </motion.div>
              )}
            </div>
          </div>

          {/* Right: Called Numbers */}
          <div>
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-white text-sm">Called Numbers ({calledNumbers.length}/75)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {BINGO_LETTERS.map((letter, colIdx) => {
                    const [min, max] = getColRange(colIdx);
                    const colNums = calledNumbers.filter(n => n >= min && n <= max);
                    return (
                      <div key={letter}>
                        <span className="text-purple-400 font-bold text-xs">{letter}</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {colNums.map(n => (
                            <span key={n} className="w-7 h-7 rounded-full bg-purple-700 text-white text-xs flex items-center justify-center font-bold">
                              {n}
                            </span>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

const CHARITY_CAMPAIGNS = [
  { id: "hunger", name: "End World Hunger", icon: "🌾", goal: 50000, raised: 31240, description: "Fund meals for families in food-insecure regions", color: "from-orange-500 to-yellow-500" },
  { id: "education", name: "Education for All", icon: "📚", goal: 75000, raised: 48900, description: "Build schools and fund scholarships globally", color: "from-blue-500 to-cyan-500" },
  { id: "climate", name: "Climate Action Fund", icon: "🌍", goal: 100000, raised: 67800, description: "Plant trees and fund renewable energy projects", color: "from-green-500 to-emerald-500" },
  { id: "shelter", name: "Homes for All", icon: "🏠", goal: 30000, raised: 22100, description: "Build emergency shelters and transitional housing", color: "from-purple-500 to-pink-500" },
  { id: "water", name: "Clean Water Access", icon: "💧", goal: 60000, raised: 41500, description: "Drill wells and install water purification systems", color: "from-sky-500 to-blue-600" },
  { id: "animals", name: "Animal Rescue", icon: "🐾", goal: 25000, raised: 18300, description: "Fund animal shelters and rescue operations", color: "from-amber-500 to-orange-600" },
];

const CHARITY_GAMES = [
  { id: "bingo", name: "Charity Bingo", icon: "🎱", path: "/game-bingo", description: "Classic Bingo — 10% of every bet donated", reward: "50-500 SKY444", players: 1247, live: true },
  { id: "scratch", name: "Scratch & Give", icon: "🎟️", path: "/game-scratch", description: "Scratch cards — 15% to charity", reward: "10-1000 SKY444", players: 892, live: true },
  { id: "wheel", name: "Charity Wheel", icon: "🎡", path: "/game-roulette", description: "Spin the wheel — 20% to charity", reward: "25-250 SKY444", players: 634, live: true },
  { id: "trivia", name: "Trivia for Good", icon: "🧠", path: "/game-trivia", description: "Answer questions — 25% to charity", reward: "5-100 SKY444", players: 2103, live: true },
  { id: "slots", name: "Charity Slots", icon: "🎰", path: "/game-slots", description: "Slot machines — 12% to charity", reward: "10-5000 SKY444", players: 1876, live: true },
  { id: "raffle", name: "SKY Raffle", icon: "🎫", path: "/game-raffle", description: "Buy tickets — 30% to charity", reward: "Jackpot: 44,444 SKY444", players: 3421, live: true },
];

const LEADERBOARD = [
  { rank: 1, name: "SkyChampion", donated: 12450, avatar: "👑" },
  { rank: 2, name: "CryptoAngel", donated: 9870, avatar: "😇" },
  { rank: 3, name: "HopeWarrior", donated: 7340, avatar: "⚡" },
  { rank: 4, name: "SkylerB", donated: 5920, avatar: "🌟" },
  { rank: 5, name: "TokenGiver", donated: 4410, avatar: "💎" },
];

export default function CharityGames() {
  const [selectedCampaign, setSelectedCampaign] = useState(CHARITY_CAMPAIGNS[0]);
  const totalRaised = CHARITY_CAMPAIGNS.reduce((s, c) => s + c.raised, 0);
  const totalGoal = CHARITY_CAMPAIGNS.reduce((s, c) => s + c.goal, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-emerald-950 to-slate-950 p-4">
      <div className="max-w-7xl mx-auto space-y-8">

        {/* Hero Banner */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-8"
        >
          <div className="text-6xl mb-4">🌟</div>
          <h1 className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-yellow-400 to-purple-400">
            Play. Win. Give.
          </h1>
          <p className="text-slate-300 text-xl mt-3 max-w-2xl mx-auto">
            Every game you play on SKYCOIN4444 contributes to real-world charity campaigns.
            Win SKY444 tokens while making the world better.
          </p>
          <div className="mt-6 flex justify-center gap-6 flex-wrap">
            <div className="text-center">
              <div className="text-3xl font-black text-emerald-400">${totalRaised.toLocaleString()}</div>
              <div className="text-slate-400 text-sm">Total Raised</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-black text-yellow-400">44,444+</div>
              <div className="text-slate-400 text-sm">Players Donated</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-black text-purple-400">6</div>
              <div className="text-slate-400 text-sm">Active Campaigns</div>
            </div>
          </div>
          {/* Overall progress */}
          <div className="max-w-xl mx-auto mt-6">
            <div className="flex justify-between text-sm text-slate-400 mb-1">
              <span>Overall Progress</span>
              <span>{Math.round((totalRaised / totalGoal) * 100)}%</span>
            </div>
            <Progress value={(totalRaised / totalGoal) * 100} className="h-3" />
          </div>
        </motion.div>

        {/* Charity Campaigns */}
        <div>
          <h2 className="text-2xl font-black text-white mb-4">🌍 Active Campaigns</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {CHARITY_CAMPAIGNS.map((campaign, i) => (
              <motion.div
                key={campaign.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => setSelectedCampaign(campaign)}
                className={`cursor-pointer rounded-2xl p-4 border-2 transition-all ${
                  selectedCampaign.id === campaign.id
                    ? "border-emerald-500 bg-emerald-900/20"
                    : "border-slate-700 bg-slate-900/50 hover:border-slate-600"
                }`}
              >
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-3xl">{campaign.icon}</span>
                  <div>
                    <div className="text-white font-bold">{campaign.name}</div>
                    <div className="text-slate-400 text-xs">{campaign.description}</div>
                  </div>
                </div>
                <Progress value={(campaign.raised / campaign.goal) * 100} className="h-2 mb-2" />
                <div className="flex justify-between text-xs">
                  <span className="text-emerald-400 font-bold">${campaign.raised.toLocaleString()} raised</span>
                  <span className="text-slate-500">Goal: ${campaign.goal.toLocaleString()}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Games Grid */}
        <div>
          <h2 className="text-2xl font-black text-white mb-4">🎮 Charity Games</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {CHARITY_GAMES.map((game, i) => (
              <motion.div
                key={game.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.06 }}
              >
                <Card className="bg-slate-900 border-slate-700 hover:border-emerald-700 transition-all group overflow-hidden">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-3">
                      <span className="text-4xl">{game.icon}</span>
                      <div className="flex flex-col items-end gap-1">
                        {game.live && <Badge className="bg-emerald-600 text-white text-xs">LIVE</Badge>}
                        <span className="text-slate-500 text-xs">{game.players.toLocaleString()} playing</span>
                      </div>
                    </div>
                    <h3 className="text-white font-black text-lg mb-1">{game.name}</h3>
                    <p className="text-slate-400 text-sm mb-3">{game.description}</p>
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-yellow-400 text-sm font-bold">{game.reward}</span>
                      <span className="text-emerald-400 text-xs">→ {selectedCampaign.icon} {selectedCampaign.name}</span>
                    </div>
                    <Link href={game.path}>
                      <Button className="w-full bg-gradient-to-r from-emerald-600 to-purple-600 hover:from-emerald-700 hover:to-purple-700 text-white font-bold group-hover:shadow-lg group-hover:shadow-emerald-500/20 transition-all">
                        Play Now
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Leaderboard + Impact */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="bg-slate-900 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">🏆 Top Charity Champions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {LEADERBOARD.map(player => (
                <div key={player.rank} className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50">
                  <span className="text-2xl w-8">{player.avatar}</span>
                  <div className="flex-1">
                    <div className="text-white font-bold text-sm">{player.name}</div>
                    <div className="text-emerald-400 text-xs">{player.donated.toLocaleString()} SKY444 donated</div>
                  </div>
                  <Badge className={player.rank === 1 ? "bg-yellow-500" : player.rank === 2 ? "bg-slate-400" : "bg-amber-700"}>
                    #{player.rank}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="bg-slate-900 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">💡 How It Works</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { step: "1", icon: "🎮", title: "Play any game", desc: "Use SKY444 tokens to play Bingo, Slots, Scratch Cards, and more" },
                { step: "2", icon: "💰", title: "Win rewards", desc: "Earn SKY444 tokens when you win — multiplied by your bet" },
                { step: "3", icon: "🌍", title: "Charity gets funded", desc: "10-30% of every bet automatically goes to your chosen campaign" },
                { step: "4", icon: "🏆", title: "Climb the leaderboard", desc: "Top donors get exclusive NFT badges and bonus SKY444 rewards" },
              ].map(item => (
                <div key={item.step} className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center text-white font-black text-sm shrink-0">
                    {item.step}
                  </div>
                  <div>
                    <div className="text-white font-semibold text-sm">{item.icon} {item.title}</div>
                    <div className="text-slate-400 text-xs">{item.desc}</div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
